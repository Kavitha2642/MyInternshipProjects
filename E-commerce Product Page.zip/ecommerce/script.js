// Basic shopping cart functionality
const addToCartButton = document.getElementById("add-to-cart");
const viewCartButton = document.getElementById("view-cart");
let cart = [];

addToCartButton.addEventListener("click", () => {
	window.alert("product is added to the card")
    // Add the product to the cart
    const product = {
        name: "Product Name",
        price: 3999.99,
    };
    cart.push(product);
    updateCartCount();
    alert(`"${product.name}" added to cart!`);
});

viewCartButton.addEventListener("click", () => {
    displayCart();
});

function updateCartCount() {
    const cartCount = document.getElementById("cart-count");
    cartCount.textContent = cart.length;
}

function displayCart() {
    if (cart.length === 0) {
        alert("Your cart is empty.");
    } else {
        const cartItems = cart.map((item) => `${item.name}: $${item.price.toFixed(2)}`);
        const cartSummary = `Cart Items:\n${cartItems.join("\n")}\nTotal: $${calculateCartTotal().toFixed(2)}`;
        alert(cartSummary);
    }
}

function calculateCartTotal() {
    return cart.reduce((total, item) => total + item.price, 0);
}

updateCartCount();



